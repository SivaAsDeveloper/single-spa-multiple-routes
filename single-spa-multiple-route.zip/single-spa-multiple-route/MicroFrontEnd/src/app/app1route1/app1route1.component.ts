import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app1route1',
  templateUrl: './app1route1.component.html',
  styleUrls: ['./app1route1.component.css']
})
export class App1route1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
