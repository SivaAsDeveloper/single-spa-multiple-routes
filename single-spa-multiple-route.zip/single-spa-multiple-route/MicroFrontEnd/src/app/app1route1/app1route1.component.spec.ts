import { ComponentFixture, TestBed } from '@angular/core/testing';

import { App1route1Component } from './app1route1.component';

describe('App1route1Component', () => {
  let component: App1route1Component;
  let fixture: ComponentFixture<App1route1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ App1route1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(App1route1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
