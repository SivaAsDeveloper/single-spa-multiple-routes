import { APP_BASE_HREF } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { App1route1Component } from './app1route1/app1route1.component';
import { App1route2Component } from './app1route2/app1route2.component';
import { App1route3Component } from './app1route3/app1route3.component';
import { EmptyRouteComponent } from './empty-route/empty-route.component';

const routes: Routes = [
  //{ path: '**', component: EmptyRouteComponent },//<< NOT WORKING >>
  { path : 'App1Route1' , component: App1route1Component},
  { path : 'App1Route2' , component: App1route2Component},
  { path : 'App1Route3' , component: App1route3Component},
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  //providers: [{ provide: APP_BASE_HREF, useValue: '/' }] //<< NOT WORKING >>
    providers: [{ provide: APP_BASE_HREF, useValue: '/app1' }]
})
export class AppRoutingModule { }
