import { ComponentFixture, TestBed } from '@angular/core/testing';

import { App1route2Component } from './app1route2.component';

describe('App1route2Component', () => {
  let component: App1route2Component;
  let fixture: ComponentFixture<App1route2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ App1route2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(App1route2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
