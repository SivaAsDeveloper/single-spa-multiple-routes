import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app1route2',
  templateUrl: './app1route2.component.html',
  styleUrls: ['./app1route2.component.css']
})
export class App1route2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
