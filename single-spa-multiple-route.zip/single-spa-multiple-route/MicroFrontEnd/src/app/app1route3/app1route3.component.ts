import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app1route3',
  templateUrl: './app1route3.component.html',
  styleUrls: ['./app1route3.component.css']
})
export class App1route3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
