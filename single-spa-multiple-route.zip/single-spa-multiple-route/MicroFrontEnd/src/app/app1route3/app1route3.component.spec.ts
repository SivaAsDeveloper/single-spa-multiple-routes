import { ComponentFixture, TestBed } from '@angular/core/testing';

import { App1route3Component } from './app1route3.component';

describe('App1route3Component', () => {
  let component: App1route3Component;
  let fixture: ComponentFixture<App1route3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ App1route3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(App1route3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
