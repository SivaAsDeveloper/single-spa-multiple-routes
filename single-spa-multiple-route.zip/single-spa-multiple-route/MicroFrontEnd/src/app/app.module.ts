import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { App1route1Component } from './app1route1/app1route1.component';
import { App1route2Component } from './app1route2/app1route2.component';
import { App1route3Component } from './app1route3/app1route3.component';

@NgModule({
  declarations: [
    AppComponent,
    App1route1Component,
    App1route2Component,
    App1route3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
